# RodaCash - Projeto Fintech

Tela única desenvolvida para a atividade avaliativa de HTML, CSS e Tailwind CSS.

## Arquivos principais

- `index.html`: página principal do projeto.
- `css/styles.css`: estilos personalizados separados do HTML.
- `docs/LINK_GITHUB_MODELO.pdf`: modelo de PDF para ser substituído pelo PDF final com o link público do repositório.

## Como abrir

Abra o arquivo `index.html` no navegador.

## Observação importante

O projeto usa Tailwind CSS via CDN de CSS. Não há JavaScript próprio no projeto.
Para a entrega final, crie um repositório público no GitHub, envie estes arquivos e gere um PDF contendo o link público do repositório.
